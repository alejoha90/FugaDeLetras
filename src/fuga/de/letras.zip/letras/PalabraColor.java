/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fuga.de.letras;

/**
 *
 * @author Alejandro
 */
public class PalabraColor extends Palabras {
    
    public PalabraColor(String palabraCompleta, String palabraSinVocal){
        super(new String[]{"AZUL", "VERDE", "ROJO", "AMARILLO", "MORADO", "NEGRO", "BLANCO", "GRIS", "ROSADO", "NARANJA", "DORADO"}, 
                new String[]{"AZ_L", "V_RDE", "R_JO", "AM_RILLO", "MOR_DO", "N_GRO", "BL_NCO", "GR_S", "ROS_DO", "NAR_NJA", "DOR_DO"});
        
        
    }
}
