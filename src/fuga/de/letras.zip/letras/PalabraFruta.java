/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fuga.de.letras;

/**
 *
 * @author Alejandro
 */
public class PalabraFruta extends Palabras {
    public PalabraFruta (String palabraCompleta, String palabraSinVocal) {
        super(new String[] {"FRESA", "MANZANA", "NARANJA", "SANDIA", "UVA", "KIWI", "MELON", "PIÑA", "LIMON", "MANGO", "PAPAYA"}, 
                new String[] {"FR_SA", "M_NZANA", "NAR_NJA", "SAND_A", "_VA", "KIW_", "MEL_N", "P_ÑA", "L_MON", "MANG_", "PAPAY_"});
        
        
    }
    
}
