/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fuga.de.letras;

/**
 *
 * @author Alejandro
 */
public class Palabras {
    private String [] palabraCompleta;
    private String [] palabraSinVocal;

    public Palabras(String[] palabraCompleta, String[] palabraSinVocal) {
        this.palabraCompleta = palabraCompleta;
        this.palabraSinVocal = palabraSinVocal;
    }
    
    
}
