/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fuga.de.letras;

/**
 *
 * @author Alejandro
 */
public class PalabraAnimal extends Palabras {
    
    public PalabraAnimal (String palabraCompleta, String palabraSinVocal) {
        super(new String[] {"GATO", "PERRO", "ELEFANTE", "JIRAFA", "LEON", "TIGRE", "MONO", "CEBRA", "OSO", "VACA", "LORO"}, 
                new String[] {"G_TO", "PERR_", "ELEF_NTE", "J_RAFA", "L_ON", "T_GRE", "M_NO", "CEBR_", "_SO", "VAC_", "L_RO"});
        
        
    }
    
    
}
